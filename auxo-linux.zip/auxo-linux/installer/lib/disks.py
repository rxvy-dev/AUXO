"""
auxo-install / disks.py
Disk discovery, free-space detection, and existing-OS detection used to
drive the "install alongside" flow safely.

All destructive operations are isolated in install_steps.py — this module
is read-only / detection-only.
"""
import json
import re
import subprocess


def run(cmd, check=True, capture=True):
    return subprocess.run(cmd, shell=isinstance(cmd, str), check=check,
                           capture_output=capture, text=True)


def list_disks():
    """Return list of dicts: {name, path, size, model, is_removable}."""
    out = run(["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,MODEL,TYPE,RM,RO"])
    data = json.loads(out.stdout)
    disks = []
    for dev in data.get("blockdevices", []):
        if dev.get("type") != "disk" or dev.get("ro") == "1" or dev.get("ro") is True:
            continue
        disks.append({
            "name": dev["name"],
            "path": dev.get("path") or f"/dev/{dev['name']}",
            "size": int(dev.get("size") or 0),
            "model": (dev.get("model") or "Unknown").strip(),
            "removable": dev.get("rm") in (True, "1"),
        })
    return disks


def human_size(nbytes):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if nbytes < 1024:
            return f"{nbytes:.1f}{unit}"
        nbytes /= 1024
    return f"{nbytes:.1f}PB"


def get_partitions(disk_path):
    """Return list of partitions on a disk with size, fstype, and mount info."""
    out = run(["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,FSTYPE,PARTTYPENAME,MOUNTPOINT", disk_path])
    data = json.loads(out.stdout)
    parts = []
    for dev in data.get("blockdevices", []):
        for child in dev.get("children", []) or []:
            parts.append({
                "name": child["name"],
                "path": child.get("path"),
                "size": int(child.get("size") or 0),
                "fstype": child.get("fstype"),
                "parttype": child.get("parttypename"),
                "mountpoint": child.get("mountpoint"),
            })
    return parts


def get_free_space_regions(disk_path):
    """
    Use `parted --script <disk> unit B print free` to find unallocated
    regions large enough to matter (>1GiB). Returns list of (start, end, size) in bytes.
    """
    try:
        out = run(["parted", "--script", disk_path, "unit", "B", "print", "free"])
    except subprocess.CalledProcessError:
        return []
    regions = []
    for line in out.stdout.splitlines():
        m = re.match(r"\s*(\d+)B\s+(\d+)B\s+(\d+)B\s+Free Space", line)
        if m:
            start, end, size = (int(m.group(i)) for i in (1, 2, 3))
            if size > 1 * 1024 ** 3:  # ignore slivers under 1GiB
                regions.append({"start": start, "end": end, "size": size})
    return regions


_OS_HINTS = {
    "ntfs": "Windows (NTFS)",
    "vfat": None,  # could be ESP or Windows recovery; refine via label
}


def detect_existing_os(disk_path):
    """
    Best-effort detection of existing operating systems on a disk, using
    filesystem types/labels and os-prober (if available). Returns list of
    human-readable strings, e.g. ["Windows 11 (NTFS, /dev/sda2)", "Ubuntu 24.04 (ext4, /dev/sda3)"]
    Never modifies anything — read-only probing.
    """
    findings = []
    parts = get_partitions(disk_path)
    for p in parts:
        fstype = (p.get("fstype") or "").lower()
        path = p["path"]
        if fstype == "ntfs":
            findings.append(f"Windows (NTFS partition, {path}, {human_size(p['size'])})")
        elif fstype in ("ext4", "ext3", "ext2", "btrfs", "xfs"):
            findings.append(f"Linux filesystem ({fstype}, {path}, {human_size(p['size'])}) — "
                             f"likely an existing Linux install")

    # os-prober gives the most accurate answer when available (needs root)
    try:
        out = run(["os-prober"], check=False)
        for line in out.stdout.splitlines():
            if line.strip():
                # format: /dev/sdXN:Label:short:type
                fields = line.split(":")
                if len(fields) >= 2:
                    findings.append(f"os-prober: {fields[1]} ({fields[0]})")
    except FileNotFoundError:
        pass

    # de-dup while preserving order
    seen = set()
    unique = []
    for f in findings:
        if f not in seen:
            seen.add(f)
            unique.append(f)
    return unique


def is_efi():
    import os
    return os.path.isdir("/sys/firmware/efi")
