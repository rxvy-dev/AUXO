"""
auxo-install / install_steps.py
Actual system-modifying operations. Every function takes an InstallState
and a `log(line)` callback for live TUI feedback. Designed to run as root
inside the Arch live ISO.

Safety notes:
- alongside-install NEVER touches existing partitions; it only creates new
  partitions inside free space that disks.get_free_space_regions() found.
- Every destructive command is logged before it runs.
"""
import os
import subprocess

from . import disks


class InstallError(RuntimeError):
    pass


def sh(cmd, log, check=True):
    log(f"$ {cmd}")
    proc = subprocess.Popen(
        cmd, shell=True, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        bufsize=1,  # line-buffered
    )
    output_lines = []
    for line in proc.stdout:
        line = line.rstrip("\n")
        output_lines.append(line)
        log(line)
    proc.wait()
    if check and proc.returncode != 0:
        raise InstallError(f"Command failed ({proc.returncode}): {cmd}")

    class _Result:
        pass
    result = _Result()
    result.returncode = proc.returncode
    result.stdout = "\n".join(output_lines)
    return result


# ---------------------------------------------------------------- #
# Partitioning
# ---------------------------------------------------------------- #

def partition_alongside(state, log):
    """
    Create a new partition inside a free-space region on state.disk, sized
    state.root_size_mb, formatted as state.filesystem. Reuses the existing
    ESP (state.esp_partition) instead of creating a new one — this is what
    makes it a true "alongside" install rather than a wipe.
    """
    disk = state.disk
    regions = disks.get_free_space_regions(disk)
    if not regions:
        raise InstallError("No usable free space region found on disk.")
    region = max(regions, key=lambda r: r["size"])  # largest gap
    start_b = region["start"]
    size_mb = state.root_size_mb or (region["size"] // (1024 * 1024) - 4)
    end_b = start_b + size_mb * 1024 * 1024

    log(f"Creating {size_mb}MiB partition in free space at byte {start_b}...")
    sh(f"parted --script {disk} unit B mkpart primary {start_b} {end_b}", log)
    sh(f"partprobe {disk}", log)

    # find the newly created partition (last partition number on disk)
    parts = disks.get_partitions(disk)
    new_part = sorted(parts, key=lambda p: p["path"])[-1]
    state.target_partition = new_part["path"]

    if state.encrypt:
        _luks_format_and_open(state, log)
        mapped = "/dev/mapper/auxo_root"
        _mkfs(mapped, state.filesystem, log)
        state.target_partition = mapped
    else:
        _mkfs(state.target_partition, state.filesystem, log)

    return state.target_partition


def erase_disk(state, log):
    """Full-disk install: GPT partition table, ESP + root."""
    disk = state.disk
    if not disks.is_efi():
        raise InstallError("BIOS/legacy systems: use manual partitioning mode.")
    log(f"WARNING: erasing entire disk {disk}")
    sh(f"sgdisk --zap-all {disk}", log)
    sh(f"parted --script {disk} mklabel gpt", log)
    sh(f"parted --script {disk} mkpart ESP fat32 1MiB 513MiB", log)
    sh(f"parted --script {disk} set 1 esp on", log)
    sh(f"parted --script {disk} mkpart primary 513MiB 100%", log)
    sh(f"partprobe {disk}", log)

    parts = disks.get_partitions(disk)
    parts.sort(key=lambda p: p["path"])
    state.esp_partition = parts[0]["path"]
    root_part = parts[1]["path"]

    sh(f"mkfs.fat -F32 {state.esp_partition}", log)

    if state.encrypt:
        state.target_partition = root_part
        _luks_format_and_open(state, log)
        mapped = "/dev/mapper/auxo_root"
        _mkfs(mapped, state.filesystem, log)
        state.target_partition = mapped
    else:
        _mkfs(root_part, state.filesystem, log)
        state.target_partition = root_part


def _luks_format_and_open(state, log):
    log("Setting up LUKS2 encryption on root partition...")
    passfile = "/tmp/.auxo_luks_pass"
    with open(passfile, "w") as f:
        f.write(state.luks_passphrase)
    os.chmod(passfile, 0o600)
    sh(f"cryptsetup luksFormat --type luks2 {state.target_partition} {passfile}", log)
    sh(f"cryptsetup open {state.target_partition} auxo_root --key-file {passfile}", log)
    os.remove(passfile)


def _mkfs(partition, fstype, log):
    fstype = fstype.lower()
    cmd = {
        "ext4": f"mkfs.ext4 -F {partition}",
        "btrfs": f"mkfs.btrfs -f {partition}",
        "xfs": f"mkfs.xfs -f {partition}",
    }.get(fstype)
    if not cmd:
        raise InstallError(f"Unsupported filesystem: {fstype}")
    sh(cmd, log)


def mount_targets(state, log):
    sh("mkdir -p /mnt/auxo", log)
    sh(f"mount {state.target_partition} /mnt/auxo", log)
    if state.esp_partition:
        sh("mkdir -p /mnt/auxo/boot", log)
        sh(f"mount {state.esp_partition} /mnt/auxo/boot", log)
    elif state.install_mode == "alongside":
        # reuse the existing ESP found during detection
        existing_esp = _find_existing_esp(state.disk)
        if existing_esp:
            sh("mkdir -p /mnt/auxo/boot", log)
            sh(f"mount {existing_esp} /mnt/auxo/boot", log)
            state.esp_partition = existing_esp
        else:
            raise InstallError("No existing EFI System Partition found to reuse.")


def _find_existing_esp(disk_path):
    for p in disks.get_partitions(disk_path):
        if (p.get("parttype") or "").lower().find("efi") != -1 or p.get("fstype") == "vfat":
            return p["path"]
    return None


# ---------------------------------------------------------------- #
# Base system
# ---------------------------------------------------------------- #

def build_package_list(state, catalog):
    pkgs = set(["base", "base-devel", "linux-firmware", "sudo", "nano", "vim",
                "networkmanager", "git", "curl", "reflector",
                "intel-ucode", "amd-ucode"])

    def add(section, key):
        entry = next((e for e in catalog[section] if e["id"] == key), None)
        if entry:
            pkgs.update(entry.get("packages", []))

    add("kernels", state.kernel)
    add("init_systems", state.init_system)
    add("desktop_environments", state.desktop_environment)
    if state.window_manager:
        add("window_managers", state.window_manager)
    add("shells", state.shell)
    add("bootloaders", state.bootloader)
    add("network_managers", state.network_manager)
    pkgs.update(state.extra_packages)
    return sorted(pkgs)


def pacstrap_base(state, catalog, log):
    pkgs = build_package_list(state, catalog)
    log(f"Installing {len(pkgs)} packages via pacstrap...")
    # No -K: reuse the live ISO's already-initialized, populated keyring
    # (see customize_airootfs.sh) instead of generating a brand new one
    # inside the target, which needs entropy that live/virtual
    # environments often don't have enough of and can fail with
    # "keyring is not writable".
    sh(f"pacstrap /mnt/auxo {' '.join(pkgs)}", log)
    sh("sync", log, check=False)  # flush the freshly-generated initramfs to disk
    sh("genfstab -U /mnt/auxo >> /mnt/auxo/etc/fstab", log)


def _chroot(cmd, log, check=True):
    return sh(f"arch-chroot /mnt/auxo /bin/bash -c \"{cmd}\"", log, check=check)


def configure_system(state, log):
    _chroot(f"ln -sf /usr/share/zoneinfo/{state.timezone} /etc/localtime", log)
    _chroot("hwclock --systohc", log)
    _chroot(f"echo '{state.locale} UTF-8' >> /etc/locale.gen", log)
    _chroot("locale-gen", log)
    _chroot(f"echo 'LANG={state.locale}' > /etc/locale.conf", log)
    _chroot(f"echo 'KEYMAP={state.keymap}' > /etc/vconsole.conf", log)
    _chroot(f"echo '{state.hostname}' > /etc/hostname", log)
    _chroot(f"printf '127.0.0.1 localhost\\n::1 localhost\\n127.0.1.1 {state.hostname}.localdomain {state.hostname}\\n' > /etc/hosts", log)
    _chroot("systemctl enable NetworkManager", log, check=False)

    # Rebrand from generic Arch to Auxo, same as the live ISO.
    with open("/mnt/auxo/etc/os-release", "w") as f:
        f.write(
            'NAME="Auxo Linux"\n'
            'PRETTY_NAME="Auxo Linux"\n'
            'ID=auxo\n'
            'ID_LIKE=arch\n'
            'BUILD_ID=rolling\n'
            'ANSI_COLOR="38;2;0;175;175"\n'
            'LOGO=auxo-logo\n'
        )
    with open("/mnt/auxo/etc/issue", "w") as f:
        f.write("Auxo Linux \\r (\\l)\n\n")

    if state.desktop_environment != "none":
        entry_dm = _display_manager_for(state)
        if entry_dm:
            _chroot(f"systemctl enable {entry_dm}", log, check=False)


def _display_manager_for(state):
    import json as _json
    here = os.path.dirname(os.path.dirname(__file__))
    catalog = _json.load(open(os.path.join(here, "config", "profiles.json")))
    entry = next((e for e in catalog["desktop_environments"] if e["id"] == state.desktop_environment), None)
    return entry.get("display_manager") if entry else None


def create_users(state, log):
    root_pass = state.root_password or state.user_password
    _chroot(f"echo 'root:{root_pass}' | chpasswd", log)
    if state.username:
        groups = "wheel" if state.grant_sudo else ""
        _chroot(f"useradd -m -G {groups} -s /usr/bin/{_shell_bin(state.shell)} {state.username}", log)
        _chroot(f"echo '{state.username}:{state.user_password}' | chpasswd", log)
        if state.grant_sudo:
            _chroot("sed -i 's/^# %wheel ALL=(ALL:ALL) ALL/%wheel ALL=(ALL:ALL) ALL/' /etc/sudoers", log)


def _shell_bin(shell_id):
    return {"bash": "bash", "zsh": "zsh", "fish": "fish", "nu": "nu"}.get(shell_id, "bash")


def install_aur_helper(state, log):
    if state.aur_helper == "none" or not state.username:
        return
    import json as _json
    here = os.path.dirname(os.path.dirname(__file__))
    catalog = _json.load(open(os.path.join(here, "config", "profiles.json")))
    entry = next((e for e in catalog["aur_helpers"] if e["id"] == state.aur_helper), None)
    if not entry or "build_from_source" not in entry:
        return
    repo = entry["build_from_source"]
    log(f"Building {state.aur_helper} from AUR as {state.username}...")
    build_cmd = (
        f"cd /home/{state.username} && "
        f"git clone {repo} {state.aur_helper}_build && "
        f"cd {state.aur_helper}_build && makepkg -si --noconfirm"
    )
    sh(f"arch-chroot /mnt/auxo /bin/su - {state.username} -c \"{build_cmd}\"", log, check=False)


# ---------------------------------------------------------------- #
# Bootloader — the critical "alongside" piece
# ---------------------------------------------------------------- #

def install_grub_splash(state, log):
    """Generate a GRUB boot splash: dark background + the mountain logo
    rendered in the user's chosen accent color, with an 'AUXO LINUX'
    wordmark underneath. Requires python-pillow + ttf-dejavu on the live
    ISO (see packages.x86_64) — skips gracefully if unavailable."""
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageFilter
    except ImportError:
        log("python-pillow not available; skipping GRUB splash generation.")
        return

    try:
        W, H = 1920, 1080
        bg_color = (10, 10, 15)
        rgb_hex = (state.theme_rgb or "00AFAF").lstrip("#")
        accent = tuple(int(rgb_hex[i:i + 2], 16) for i in (0, 2, 4))

        img = Image.new("RGB", (W, H), bg_color)
        cx, cy = W // 2, H // 2 - 60
        scale = 260
        outer = [
            (cx, cy - scale),
            (cx - scale * 0.95, cy + scale),
            (cx + scale * 0.95, cy + scale),
        ]
        inner = [
            (cx, cy - scale * 0.45),
            (cx - scale * 0.42, cy + scale),
            (cx + scale * 0.42, cy + scale),
        ]

        # Soft glow behind the outline
        glow_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(glow_layer).polygon(outer, outline=accent + (255,), width=18)
        glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(20))
        img = Image.alpha_composite(img.convert("RGBA"), glow_layer).convert("RGB")

        draw = ImageDraw.Draw(img)
        draw.polygon(outer, outline=accent, width=6)
        draw.polygon(inner, outline=accent, width=4)

        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 64)
        except Exception:
            font = ImageFont.load_default()
        text = "A U X O   L I N U X"
        bbox = draw.textbbox((0, 0), text, font=font)
        tw = bbox[2] - bbox[0]
        draw.text((cx - tw / 2, cy + scale + 60), text, font=font, fill=accent)

        out_dir = "/mnt/auxo/boot/grub"
        os.makedirs(out_dir, exist_ok=True)
        out_path = f"{out_dir}/splash.png"
        img.save(out_path)
        log(f"Generated GRUB splash at {out_path}")

        # Unquoted value — sidesteps nested-shell-quoting issues, and a
        # plain path with no spaces is equally valid in /etc/default/grub.
        _chroot("grep -q GRUB_BACKGROUND /etc/default/grub || "
                "echo GRUB_BACKGROUND=/boot/grub/splash.png >> /etc/default/grub", log, check=False)
        _chroot("sed -i 's#^GRUB_BACKGROUND=.*#GRUB_BACKGROUND=/boot/grub/splash.png#' /etc/default/grub",
                log, check=False)
    except Exception as e:
        log(f"GRUB splash generation failed ({e}); continuing without it.")


def install_bootloader(state, log):
    if state.bootloader == "grub":
        _chroot("pacman -S --noconfirm grub os-prober efibootmgr", log, check=False)
        _chroot("grub-install --target=x86_64-efi --efi-directory=/boot --bootloader-id=Auxo", log)
        # Also write to the fallback EFI path (\EFI\BOOT\BOOTX64.EFI). Some
        # UEFI firmware (notably on some Acer/consumer laptops) doesn't
        # reliably honor the NVRAM boot entry grub-install just created,
        # showing a "missing device" error instead. The fallback path is
        # checked by virtually all firmware regardless of NVRAM state, so
        # this makes the install bootable even on flaky firmware.
        _chroot("grub-install --target=x86_64-efi --efi-directory=/boot --bootloader-id=Auxo --removable",
                log, check=False)
        # Verify (and if needed, manually recreate) the NVRAM boot entry —
        # grub-install's internal efibootmgr call can fail silently.
        result = _chroot("efibootmgr", log, check=False)
        if "Auxo" not in (result.stdout or ""):
            log("NVRAM boot entry for Auxo not found after grub-install; adding it manually...")
            import re
            m = re.match(r"^(/dev/(?:nvme\d+n\d+p|mmcblk\d+p|[a-z]+))(\d+)$", state.esp_partition)
            if m:
                esp_disk, esp_part_num = m.group(1), m.group(2)
                # Written as a real script file rather than nested through
                # _chroot's shell quoting (bash -c "...") — that would
                # silently mangle the backslashes in the EFI path and the
                # quoted "Auxo Linux" label.
                script_path = "/mnt/auxo/tmp/auxo_add_bootentry.sh"
                with open(script_path, "w") as f:
                    f.write(
                        "#!/bin/bash\n"
                        f"efibootmgr --create --disk {esp_disk} --part {esp_part_num} "
                        "--loader '\\EFI\\Auxo\\grubx64.efi' --label 'Auxo Linux'\n"
                    )
                os.chmod(script_path, 0o755)
                _chroot("bash /tmp/auxo_add_bootentry.sh", log, check=False)
                os.remove(script_path)
            else:
                log(f"Couldn't parse disk/partition from {state.esp_partition}; "
                    f"skipping manual NVRAM entry (the --removable fallback path above should "
                    f"still make this bootable).")
        # This is what makes dual-boot actually work: enable os-prober so
        # GRUB detects the Windows/Linux install(s) we found during scan.
        _chroot("sed -i 's/#GRUB_DISABLE_OS_PROBER=false/GRUB_DISABLE_OS_PROBER=false/' /etc/default/grub", log, check=False)
        _chroot("echo 'GRUB_DISABLE_OS_PROBER=false' >> /etc/default/grub", log, check=False)
        # GRUB_DISTRIBUTOR is what actually controls the menu label — the
        # grub package ships this hardcoded to "Arch" regardless of
        # /etc/os-release, so without this override every entry reads
        # "Arch Linux" instead of "Auxo Linux".
        _chroot("sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR=Auxo/' /etc/default/grub", log, check=False)
        # Force text-mode video handoff instead of a graphics mode switch.
        # Graphical GFXPAYLOAD handoff is a known cause of boot hangs right
        # after "Loading initial ramdisk" on some hardware/GPU combos.
        _chroot("sed -i 's/^GRUB_GFXPAYLOAD_LINUX=.*/GRUB_GFXPAYLOAD_LINUX=text/' /etc/default/grub", log, check=False)
        _chroot("grep -q GRUB_GFXPAYLOAD_LINUX /etc/default/grub || echo 'GRUB_GFXPAYLOAD_LINUX=text' >> /etc/default/grub", log, check=False)
        install_grub_splash(state, log)
        _chroot("grub-mkconfig -o /boot/grub/grub.cfg", log)
        sh("sync", log, check=False)
    elif state.bootloader == "systemd-boot":
        _chroot("bootctl install", log)
        _write_systemd_boot_entry(state, log)
    elif state.bootloader == "rEFInd":
        _chroot("pacman -S --noconfirm refind", log, check=False)
        _chroot("refind-install", log)
    else:
        raise InstallError(f"Unknown bootloader: {state.bootloader}")


def _write_systemd_boot_entry(state, log):
    entry = f"""title   Auxo Linux ({state.kernel})
linux   /vmlinuz-{state.kernel}
initrd  /initramfs-{state.kernel}.img
options root={state.target_partition} rw
"""
    path = "/mnt/auxo/boot/loader/entries/auxo.conf"
    sh(f"mkdir -p /mnt/auxo/boot/loader/entries", log)
    with open(path, "w") as f:
        f.write(entry)
    log(f"Wrote systemd-boot entry to {path}")
    log("Note: systemd-boot won't auto-chain other OSes; add manual entries "
        "for other installs, or switch to GRUB for automatic detection.")


def install_wm_dotfiles(state, catalog, log):
    """Generic dotfiles auto-clone: any window_manager entry in profiles.json
    can carry a 'dotfiles' repo URL, and it gets cloned + best-effort applied
    for the new user automatically. This is what wires up Hyprland ->
    rxvy-dev/rxvy-hyprland-dotfiles without hardcoding it here."""
    if not state.window_manager or not state.username:
        return
    entry = next((e for e in catalog["window_managers"] if e["id"] == state.window_manager), None)
    if not entry or not entry.get("dotfiles"):
        return
    repo = entry["dotfiles"]
    home = f"/home/{state.username}"
    clone_dir = f"{home}/{entry['id']}-dotfiles"
    log(f"Cloning {entry['name']} dotfiles from {repo}...")
    sh(f"arch-chroot /mnt/auxo /bin/su - {state.username} -c \"git clone {repo} {clone_dir}\"", log, check=False)
    setup_cmd = (
        f"cd {clone_dir} 2>/dev/null && "
        f"([ -f install.sh ] && bash install.sh) || "
        f"([ -d .config ] && mkdir -p {home}/.config && cp -rT .config {home}/.config) || "
        f"([ -d config ] && mkdir -p {home}/.config && cp -rT config {home}/.config) || true"
    )
    sh(f"arch-chroot /mnt/auxo /bin/su - {state.username} -c \"{setup_cmd}\"", log, check=False)
    log(f"{entry['name']} dotfiles applied (see ~/{entry['id']}-dotfiles for the original repo/README).")


def apply_theme(state, log):
    """Bake the chosen accent color into the fresh install: colorized MOTD
    and a system theme.conf that auxo-fetch/auxo-choose pick up immediately."""
    from . import ascii_art, theme
    entry = theme.find_by_name(state.theme_name)
    motd_content = theme.render_motd_text(entry, ascii_art.AUXO_LOGO_FULL)
    with open("/mnt/auxo/etc/motd", "w") as f:
        f.write(motd_content)
    os.makedirs("/mnt/auxo/etc/auxo", exist_ok=True)
    with open("/mnt/auxo/etc/auxo/theme.conf", "w") as f:
        f.write(f"NAME={entry[0]}\nANSI={entry[3]}\nRGB={entry[4]}\n")
    log(f"Applied accent color: {entry[0]}")


def install_first_light(state, log):
    """Install the one-time 'First Light' boot animation. Gated entirely
    by systemd's ConditionPathExists (not the script itself), so it's
    guaranteed to run exactly once on this machine's real first boot and
    never again — no setting to accidentally re-trigger it."""
    import shutil
    installer_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    project_root = os.path.dirname(installer_dir)
    src = os.path.join(project_root, "post-install", "auxo-firstlight")
    if not os.path.isfile(src):
        log("auxo-firstlight script not found; skipping First Light setup.")
        return

    dest = "/mnt/auxo/usr/local/bin/auxo-firstlight"
    shutil.copy(src, dest)
    os.chmod(dest, 0o755)

    unit = """[Unit]
Description=Auxo Linux First Light (one-time welcome)
DefaultDependencies=no
After=systemd-vconsole-setup.service
Before=display-manager.service getty@tty1.service
Conflicts=shutdown.target
ConditionPathExists=!/var/lib/auxo/.first_light_shown

[Service]
Type=oneshot
StandardOutput=tty
StandardInput=tty
TTYPath=/dev/tty1
ExecStart=/usr/local/bin/auxo-firstlight
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
"""
    os.makedirs("/mnt/auxo/etc/systemd/system", exist_ok=True)
    with open("/mnt/auxo/etc/systemd/system/auxo-firstlight.service", "w") as f:
        f.write(unit)
    _chroot("systemctl enable auxo-firstlight.service", log, check=False)
    log("First Light will play once, on this machine's very first boot.")


def install_timecapsule_hook(state, log):
    """Install the /etc/profile.d hook that surfaces a time-capsule
    message on its due date, then archives it so it only shows once.
    Works for bash/zsh (which source /etc/profile.d/*.sh via /etc/profile).
    fish/nu users can add their own equivalent — those shells don't source
    POSIX sh profile scripts."""
    hook = r"""#!/bin/sh
# Auxo time-capsule: show any message left for today, once, then archive it.
TODAY=$(date +%Y-%m-%d)
CAPSULE_DIR="$HOME/.config/auxo/timecapsules"
CAPSULE_FILE="$CAPSULE_DIR/$TODAY.txt"
if [ -f "$CAPSULE_FILE" ]; then
    mkdir -p "$CAPSULE_DIR/.delivered"
    ANSI=36
    [ -f /etc/auxo/theme.conf ] && ANSI=$(grep '^ANSI=' /etc/auxo/theme.conf | cut -d= -f2)
    [ -z "$ANSI" ] && ANSI=36
    MSG=$(grep '^MESSAGE=' "$CAPSULE_FILE" | cut -d= -f2-)
    CREATED=$(grep '^CREATED=' "$CAPSULE_FILE" | cut -d= -f2)
    printf '\n\033[%sm\xe2\x9c\x89 A message from you, %s:\033[0m\n' "$ANSI" "$CREATED"
    printf '\033[1m%s\033[0m\n\n' "$MSG"
    mv "$CAPSULE_FILE" "$CAPSULE_DIR/.delivered/"
fi
"""
    os.makedirs("/mnt/auxo/etc/profile.d", exist_ok=True)
    with open("/mnt/auxo/etc/profile.d/auxo-timecapsule.sh", "w") as f:
        f.write(hook)
    os.chmod("/mnt/auxo/etc/profile.d/auxo-timecapsule.sh", 0o755)
    log("Time-capsule hook installed (run 'auxo-timecapsule' anytime to leave yourself a message).")


def install_birthday_hook(state, log):
    """Store the birthday (if given) and install a recurring login-time
    check that shows a happy-birthday message every year it comes around
    — unlike the time-capsule hook, this one never archives itself."""
    if not state.birthday:
        return
    os.makedirs("/mnt/auxo/etc/auxo", exist_ok=True)
    with open("/mnt/auxo/etc/auxo/birthday.conf", "w") as f:
        f.write(f"BIRTHDAY={state.birthday}\n")

    hook = r"""#!/bin/sh
# Auxo birthday: says happy birthday, every year, on the day.
if [ -f /etc/auxo/birthday.conf ]; then
    BDAY=$(grep '^BIRTHDAY=' /etc/auxo/birthday.conf | cut -d= -f2)
    TODAY=$(date +%m-%d)
    if [ -n "$BDAY" ] && [ "$BDAY" = "$TODAY" ]; then
        ANSI=36
        [ -f /etc/auxo/theme.conf ] && ANSI=$(grep '^ANSI=' /etc/auxo/theme.conf | cut -d= -f2)
        [ -z "$ANSI" ] && ANSI=36
        printf '\n\033[1m\033[%sm\xf0\x9f\x8e\x82 Happy birthday! Auxo remembered.\033[0m\n\n' "$ANSI"
    fi
fi
"""
    os.makedirs("/mnt/auxo/etc/profile.d", exist_ok=True)
    with open("/mnt/auxo/etc/profile.d/auxo-birthday.sh", "w") as f:
        f.write(hook)
    os.chmod("/mnt/auxo/etc/profile.d/auxo-birthday.sh", 0o755)
    log(f"Birthday set to {state.birthday} — Auxo will remember, every year.")


def install_auxo_tools(state, log):
    """Copy the installer's own tooling (auxo-tweak, auxo-fetch, auxo-choose,
    and the shared lib/) onto the freshly installed system so they're
    available after first boot, not just from the live ISO."""
    import shutil
    installer_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # .../installer
    project_root = os.path.dirname(installer_dir)  # .../auxo-linux
    dest = "/mnt/auxo/opt/auxo"
    log("Installing Auxo tools (auxo-tweak, auxo-fetch, auxo-choose, auxo-timecapsule) onto the new system...")
    os.makedirs(dest, exist_ok=True)
    for name in ("installer", "post-install"):
        srcdir = os.path.join(project_root, name)
        if os.path.isdir(srcdir):
            shutil.copytree(srcdir, os.path.join(dest, name), dirs_exist_ok=True)
    _chroot("chmod +x /opt/auxo/installer/auxo-install /opt/auxo/post-install/auxo-tweak "
            "/opt/auxo/post-install/auxo-fetch /opt/auxo/post-install/auxo-choose "
            "/opt/auxo/post-install/auxo-timecapsule", log, check=False)
    _chroot("ln -sf /opt/auxo/post-install/auxo-tweak /usr/local/bin/auxo-tweak", log, check=False)
    _chroot("ln -sf /opt/auxo/post-install/auxo-fetch /usr/local/bin/auxo-fetch", log, check=False)
    _chroot("ln -sf /opt/auxo/post-install/auxo-choose /usr/local/bin/auxo-choose", log, check=False)
    _chroot("ln -sf /opt/auxo/post-install/auxo-timecapsule /usr/local/bin/auxo-timecapsule", log, check=False)


def finish(state, log):
    sh("umount -R /mnt/auxo", log, check=False)
    log("Installation complete. You can reboot now.")
