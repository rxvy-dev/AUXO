"""
auxo-install / ascii_art.py
The Auxo Linux mountain logo, shared by every tool that wants to show it
(installer welcome screen, auxo-fetch, auxo-choose, generated MOTD).
Kept dependency-free (no curses import) so plain CLI tools can use it too.
"""

AUXO_LOGO_FULL = r"""
            /\
           /  \
          / /\ \
         / /  \ \
        / /    \ \
       / /______\ \
      / /_      _\ \
     / /  \    /  \ \
    / /    \  /    \ \
   /_/      \/      \_\
"""

# Compact one-line wordmark for per-screen headers where the full mountain
# would eat too much vertical space.
AUXO_WORDMARK = "▲ AUXO LINUX ▲"


import datetime


def mountain_progress(percent):
    """Reveal the mountain bottom-to-top as percent climbs from 0-100 —
    like actually climbing it. Plants a flag at the peak at 100%."""
    lines = AUXO_LOGO_FULL.strip("\n").splitlines()
    n = len(lines)
    revealed = int(round(n * max(0, min(100, percent)) / 100))
    out = []
    for i, line in enumerate(lines):
        if i >= n - revealed:
            out.append(line)
        else:
            out.append(" " * len(line))
    if percent >= 100 and out[0].strip():
        peak = out[0]
        idx = len(peak) - len(peak.lstrip())
        out[0] = peak[:idx] + "\U0001F6A9" + peak[idx + 1:]
    return out


def current_season(dt=None):
    month = (dt or datetime.date.today()).month
    if month in (12, 1, 2):
        return "winter"
    if month in (3, 4, 5):
        return "spring"
    if month in (6, 7, 8):
        return "summer"
    return "autumn"


# Which mountain lines get a seasonal tint instead of the base accent color.
# Peak = first 3 lines, base = last 2 lines. Summer is unmodified (peak
# season = your own color, as-is).
_SEASON_TINTS = {
    "winter": ("1;37", "peak"),   # snowcap
    "spring": ("1;32", "base"),   # green shoots at the base
    "summer": (None, None),
    "autumn": ("1;33", "peak"),   # golden peak
}


def seasonal_mountain_lines(base_ansi, dt=None):
    """Returns [(line, ansi_code), ...] with a subtle seasonal tint applied
    to part of the mountain — quietly alive, no interaction needed."""
    lines = AUXO_LOGO_FULL.strip("\n").splitlines()
    n = len(lines)
    tint_ansi, region = _SEASON_TINTS[current_season(dt)]
    out = []
    for i, line in enumerate(lines):
        use_tint = tint_ansi and (
            (region == "peak" and i < 3) or (region == "base" and i >= n - 2)
        )
        out.append((line, tint_ansi if use_tint else base_ansi))
    return out


def colorize(text, ansi_code, reset="\033[0m"):
    """Wrap each line of `text` in an ANSI color code. Used by plain
    (non-curses) tools like auxo-fetch."""
    return "\n".join(f"\033[{ansi_code}m{line}{reset}" for line in text.splitlines())
