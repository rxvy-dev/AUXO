"""
auxo-install / state.py
Accumulates all wizard choices into a single dict-backed object.
Can be dumped to JSON so a full install is reproducible / scriptable
(e.g. `auxo-install --replay myconfig.json` for unattended installs —
part of "more freedom": you're never forced through the wizard twice).
"""
import json
import dataclasses
from typing import Optional, List


@dataclasses.dataclass
class InstallState:
    # target disk / partitioning
    disk: Optional[str] = None
    install_mode: str = "alongside"       # "alongside" | "erase_disk" | "manual"
    target_partition: Optional[str] = None  # partition to install root to
    esp_partition: Optional[str] = None     # EFI system partition to reuse (alongside mode)
    root_size_mb: Optional[int] = None      # size to allocate when shrinking free space

    # filesystem / encryption
    filesystem: str = "ext4"              # ext4 | btrfs | xfs
    encrypt: bool = False
    luks_passphrase: Optional[str] = None

    # components (ids reference profiles.json)
    kernel: str = "linux"
    init_system: str = "systemd"
    desktop_environment: str = "none"
    window_manager: Optional[str] = None
    aur_helper: str = "paru"
    shell: str = "zsh"
    bootloader: str = "grub"
    network_manager: str = "networkmanager"

    extra_packages: List[str] = dataclasses.field(default_factory=list)

    # theme (set via the color-picker step, applied to the fresh install's
    # MOTD; can be changed anytime after with auxo-choose)
    theme_name: str = "Auxo Cyan (default)"
    theme_ansi: str = "36"
    theme_rgb: str = "00AFAF"
    birthday: str = ""  # MM-DD, empty = skipped

    # system identity
    hostname: str = "auxo"
    timezone: str = "UTC"
    locale: str = "en_US.UTF-8"
    keymap: str = "us"

    # users
    username: Optional[str] = None
    user_password: Optional[str] = None
    root_password: Optional[str] = None
    grant_sudo: bool = True

    def to_json(self, path):
        d = dataclasses.asdict(self)
        # never persist secrets to disk in plaintext by default
        for k in ("luks_passphrase", "user_password", "root_password"):
            d[k] = None
        with open(path, "w") as f:
            json.dump(d, f, indent=2)

    @classmethod
    def from_json(cls, path):
        with open(path) as f:
            d = json.load(f)
        return cls(**d)
