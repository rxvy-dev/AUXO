"""
auxo-install / theme.py
Auxo's system-wide accent color. Deliberately limited to the portable
16-color ANSI/curses palette (base 8 + bold "bright" variants) so it looks
correct on a bare Linux console (tty1), not just a fancy terminal emulator
with 256-color/truecolor support.

Shared by:
  - the installer wizard (color-picker step, baked into the fresh install)
  - auxo-choose (post-install, change it anytime)
  - auxo-fetch (reads it to color the logo)
  - the generated /etc/motd (colored login banner)
"""
import curses
import os
import subprocess

# Each entry: (display name, curses color constant, bold?, ANSI SGR code, RGB hex)
PALETTE = [
    ("Auxo Cyan (default)", curses.COLOR_CYAN,    False, "36",   "00AFAF"),
    ("Crimson Red",         curses.COLOR_RED,     True,  "1;31", "FF3C3C"),
    ("Amber Yellow",        curses.COLOR_YELLOW,  True,  "1;33", "FFC107"),
    ("Emerald Green",       curses.COLOR_GREEN,   True,  "1;32", "2ECC71"),
    ("Ocean Blue",          curses.COLOR_BLUE,    True,  "1;34", "3498DB"),
    ("Violet Magenta",      curses.COLOR_MAGENTA, True,  "1;35", "9B59B6"),
    ("Steel White",         curses.COLOR_WHITE,   False, "37",   "DCDCDC"),
    ("Deep Purple",         curses.COLOR_MAGENTA, False, "35",   "6C3483"),
]

DEFAULT_ENTRY = PALETTE[0]

SYSTEM_THEME_PATH = "/etc/auxo/theme.conf"
USER_THEME_PATH = os.path.expanduser("~/.config/auxo/theme.conf")


def find_by_name(name):
    for entry in PALETTE:
        if entry[0] == name:
            return entry
    return DEFAULT_ENTRY


def load_theme(paths=None):
    """Returns a dict like {'NAME': ..., 'ANSI': ...} from the first theme
    file found (user theme takes priority over system theme), or None."""
    candidates = paths or [USER_THEME_PATH, SYSTEM_THEME_PATH]
    for path in candidates:
        if path and os.path.exists(path):
            data = {}
            with open(path) as f:
                for line in f:
                    if "=" in line:
                        k, v = line.strip().split("=", 1)
                        data[k] = v
            return data
    return None


def render_motd_text(entry, ascii_logo):
    """Build the full colorized MOTD text for a chosen palette entry.
    Applies a subtle seasonal tint (see ascii_art.seasonal_mountain_lines)
    on top of the base accent color."""
    name, _curses_color, _bold, ansi, _rgb = entry
    from . import ascii_art
    seasonal = ascii_art.seasonal_mountain_lines(ansi)
    lines = [f"\033[{a}m{line}\033[0m" for line, a in seasonal]
    lines.append(f"\033[{ansi}mAuxo Linux — accent: {name}. "
                  f"Run 'auxo-fetch' or 'auxo-choose' anytime.\033[0m")
    return "\n".join(lines) + "\n"


def write_user_theme(entry, path=None):
    name, _curses_color, _bold, ansi, rgb = entry
    path = path or USER_THEME_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(f"NAME={name}\nANSI={ansi}\nRGB={rgb}\n")
    return path


def write_system_motd(entry, ascii_logo, motd_path=SYSTEM_THEME_PATH, use_sudo=True):
    """Write the colorized MOTD. use_sudo=True for post-install tools running
    as a regular user; use_sudo=False when already root (e.g. the installer
    itself, writing straight to the mounted target filesystem)."""
    content = render_motd_text(entry, ascii_logo)
    if use_sudo:
        subprocess.run(["sudo", "tee", motd_path], input=content, text=True, capture_output=True)
    else:
        with open(motd_path, "w") as f:
            f.write(content)
