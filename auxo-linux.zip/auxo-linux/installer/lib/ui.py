"""
auxo-install / ui.py
Small, dependency-free curses widget kit. Stdlib `curses` only, so it runs
on any Arch live ISO with zero extra packages.
"""
import curses
import textwrap

from . import theme as _theme
from . import ascii_art as _ascii_art


class UI:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        curses.curs_set(0)
        curses.start_color()
        curses.use_default_colors()
        # pair 1 = theme/banner color (mutable via set_theme), starts at
        # the default Auxo Cyan until the user picks something else.
        default_entry = _theme.DEFAULT_ENTRY
        curses.init_pair(1, default_entry[1], -1)
        self.theme_attr = curses.A_BOLD if default_entry[2] else 0
        curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_CYAN)  # selected
        curses.init_pair(3, curses.COLOR_GREEN, -1)    # ok / success
        curses.init_pair(4, curses.COLOR_RED, -1)      # error
        curses.init_pair(5, curses.COLOR_YELLOW, -1)   # warn / hint
        curses.init_pair(6, curses.COLOR_CYAN, -1)     # scratch (color picker preview)
        self.stdscr.keypad(True)

    def set_theme(self, curses_color, bold=False):
        """Re-theme the banner/accent color for the rest of the session."""
        curses.init_pair(1, curses_color, -1)
        self.theme_attr = curses.A_BOLD if bold else 0

    # ---------- low level helpers ----------
    def _header(self, title, subtitle=""):
        self.stdscr.erase()
        h, w = self.stdscr.getmaxyx()
        banner = f" {_ascii_art.AUXO_WORDMARK} INSTALLER "
        self.stdscr.addstr(0, max(0, (w - len(banner)) // 2), banner,
                            curses.color_pair(1) | self.theme_attr)
        self.stdscr.addstr(1, 2, title[:w - 4], curses.A_BOLD)
        if subtitle:
            for i, line in enumerate(textwrap.wrap(subtitle, w - 4)):
                self.stdscr.addstr(2 + i, 2, line, curses.color_pair(5))
        return h, w

    def splash(self, title, subtitle=""):
        """Full-mountain splash screen (welcome screen, etc). Returns (h, w)
        and leaves the cursor position after the art so callers can keep
        drawing below it."""
        self.stdscr.erase()
        h, w = self.stdscr.getmaxyx()
        art_lines = _ascii_art.AUXO_LOGO_FULL.strip("\n").splitlines()
        y = 1
        for line in art_lines:
            x = max(0, (w - len(line)) // 2)
            if y < h - 2:
                self.stdscr.addstr(y, x, line, curses.color_pair(1) | self.theme_attr | curses.A_BOLD)
            y += 1
        y += 1
        label = "A U X O   L I N U X"
        self.stdscr.addstr(y, max(0, (w - len(label)) // 2), label, curses.color_pair(1) | self.theme_attr | curses.A_BOLD)
        y += 2
        self.stdscr.addstr(y, 2, title[:w - 4], curses.A_BOLD)
        y += 1
        if subtitle:
            for line in textwrap.wrap(subtitle, w - 4):
                self.stdscr.addstr(y, 2, line, curses.color_pair(5))
                y += 1
        return y + 1, w

    # ---------- widgets ----------
    def menu(self, title, options, subtitle="", start_index=0):
        """options: list[str]. Returns chosen index or None if cancelled (q/ESC)."""
        idx = start_index
        while True:
            h, w = self._header(title, subtitle)
            top = 4 + (2 if subtitle else 0)
            for i, opt in enumerate(options):
                y = top + i
                if y >= h - 2:
                    break
                attr = curses.color_pair(2) if i == idx else curses.A_NORMAL
                line = f" {'>' if i == idx else ' '} {opt} "
                self.stdscr.addstr(y, 2, line[:w - 4], attr)
            self.stdscr.addstr(h - 1, 2, "↑/↓ move   Enter select   q cancel", curses.A_DIM)
            self.stdscr.refresh()
            key = self.stdscr.getch()
            if key in (curses.KEY_UP, ord('k')):
                idx = (idx - 1) % len(options)
            elif key in (curses.KEY_DOWN, ord('j')):
                idx = (idx + 1) % len(options)
            elif key in (curses.KEY_ENTER, 10, 13):
                return idx
            elif key in (ord('q'), 27):
                return None

    def checklist(self, title, options, subtitle="", preselected=None):
        """options: list[str]. Returns set of chosen indices, or None if cancelled."""
        selected = set(preselected or [])
        idx = 0
        while True:
            h, w = self._header(title, subtitle)
            top = 4 + (2 if subtitle else 0)
            for i, opt in enumerate(options):
                y = top + i
                if y >= h - 2:
                    break
                mark = "[x]" if i in selected else "[ ]"
                attr = curses.color_pair(2) if i == idx else curses.A_NORMAL
                self.stdscr.addstr(y, 2, f" {mark} {opt}"[:w - 4], attr)
            self.stdscr.addstr(h - 1, 2, "↑/↓ move  Space toggle  Enter confirm  q cancel", curses.A_DIM)
            self.stdscr.refresh()
            key = self.stdscr.getch()
            if key in (curses.KEY_UP, ord('k')):
                idx = (idx - 1) % len(options)
            elif key in (curses.KEY_DOWN, ord('j')):
                idx = (idx + 1) % len(options)
            elif key == ord(' '):
                selected.symmetric_difference_update({idx})
            elif key in (curses.KEY_ENTER, 10, 13):
                return selected
            elif key in (ord('q'), 27):
                return None

    def text_input(self, title, prompt, default="", secret=False):
        curses.curs_set(1)
        curses.echo(not secret)
        h, w = self._header(title)
        self.stdscr.addstr(4, 2, prompt)
        self.stdscr.addstr(6, 2, "> ")
        self.stdscr.refresh()
        win = curses.newwin(1, w - 6, 6, 4)
        win.keypad(True)
        buf = list(default)
        while True:
            win.erase()
            shown = ("*" * len(buf)) if secret else "".join(buf)
            win.addstr(0, 0, shown[-(w - 8):])
            win.refresh()
            ch = win.getch()
            if ch in (curses.KEY_ENTER, 10, 13):
                break
            elif ch in (curses.KEY_BACKSPACE, 127, 8):
                if buf:
                    buf.pop()
            elif ch == 27:
                buf = list(default)
                break
            elif 32 <= ch <= 126:
                buf.append(chr(ch))
        curses.noecho()
        curses.curs_set(0)
        return "".join(buf)

    def confirm(self, title, message, default_yes=False):
        options = ["Yes", "No"]
        idx = 0 if default_yes else 1
        while True:
            h, w = self._header(title, message)
            top = 6
            for i, opt in enumerate(options):
                attr = curses.color_pair(2) if i == idx else curses.A_NORMAL
                self.stdscr.addstr(top, 4 + i * 10, f" {opt} ", attr)
            self.stdscr.addstr(h - 1, 2, "←/→ choose   Enter confirm", curses.A_DIM)
            self.stdscr.refresh()
            key = self.stdscr.getch()
            if key in (curses.KEY_LEFT, curses.KEY_RIGHT, ord('h'), ord('l'), ord('\t')):
                idx = 1 - idx
            elif key in (curses.KEY_ENTER, 10, 13):
                return idx == 0
            elif key in (ord('q'), 27):
                return False

    def info(self, title, lines, wait=True):
        h, w = self._header(title)
        y = 4
        for line in lines:
            for wrapped in textwrap.wrap(line, w - 4) or [""]:
                if y >= h - 2:
                    break
                self.stdscr.addstr(y, 2, wrapped)
                y += 1
        if wait:
            self.stdscr.addstr(h - 1, 2, "Press any key to continue...", curses.A_DIM)
            self.stdscr.refresh()
            self.stdscr.getch()
        else:
            self.stdscr.refresh()

    def log_screen(self, title):
        """Returns a callable log(line) that appends scrolling output, e.g. during pacstrap."""
        h, w = self._header(title)
        self.stdscr.refresh()
        buf = []
        top = 3

        def log(line):
            buf.append(line)
            h2, w2 = self.stdscr.getmaxyx()
            visible = buf[-(h2 - top - 2):]
            for i in range(top, h2 - 1):
                self.stdscr.move(i, 0)
                self.stdscr.clrtoeol()
            for i, l in enumerate(visible):
                self.stdscr.addstr(top + i, 2, l[:w2 - 4])
            self.stdscr.refresh()

        return log

    def color_picker(self, title, palette=None, subtitle="←/→ cycle colors   Enter confirm"):
        """Live-preview accent color picker: recolors the mountain logo as
        you cycle. Returns the chosen palette entry (name, curses_color, bold, ansi)."""
        palette = palette or _theme.PALETTE
        idx = 0
        art_lines = _ascii_art.AUXO_LOGO_FULL.strip("\n").splitlines()
        while True:
            name, curses_color, bold, _ansi, _rgb = palette[idx]
            curses.init_pair(6, curses_color, -1)
            attr = curses.color_pair(6) | (curses.A_BOLD if bold else 0)

            self.stdscr.erase()
            h, w = self.stdscr.getmaxyx()
            self.stdscr.addstr(1, 2, title[:w - 4], curses.A_BOLD)

            y = 3
            for line in art_lines:
                x = max(0, (w - len(line)) // 2)
                if y < h - 4:
                    self.stdscr.addstr(y, x, line, attr | curses.A_BOLD)
                y += 1
            y += 1
            label = f"‹ {name} ›"
            self.stdscr.addstr(y, max(0, (w - len(label)) // 2), label, attr | curses.A_BOLD)

            self.stdscr.addstr(h - 1, 2, subtitle, curses.A_DIM)
            self.stdscr.refresh()
            key = self.stdscr.getch()
            if key in (curses.KEY_LEFT, ord('h')):
                idx = (idx - 1) % len(palette)
            elif key in (curses.KEY_RIGHT, ord('l'), ord('\t')):
                idx = (idx + 1) % len(palette)
            elif key in (curses.KEY_ENTER, 10, 13):
                return palette[idx]
            elif key in (ord('q'), 27):
                return palette[0]

    def mountain_progress_screen(self, title):
        """Returns (log, set_progress). log(line) appends scrolling detail
        text below the mountain; set_progress(percent) redraws the mountain
        fill level. The mountain climbs bottom-to-top and plants a flag
        at 100%."""
        h, w = self.stdscr.getmaxyx()
        self.stdscr.erase()
        self.stdscr.addstr(1, 2, title, curses.A_BOLD)
        art_height = len(_ascii_art.AUXO_LOGO_FULL.strip("\n").splitlines())
        mountain_top = 3
        percent_row = mountain_top + art_height + 1
        log_top = percent_row + 2
        state = {"percent": 0}
        log_buf = []

        def _draw_mountain():
            h2, w2 = self.stdscr.getmaxyx()
            frame = _ascii_art.mountain_progress(state["percent"])
            attr = curses.color_pair(1) | self.theme_attr | curses.A_BOLD
            for i, fline in enumerate(frame):
                y = mountain_top + i
                if y >= h2:
                    break
                self.stdscr.move(y, 0)
                self.stdscr.clrtoeol()
                x = max(0, (w2 - len(fline)) // 2)
                try:
                    self.stdscr.addstr(y, x, fline, attr)
                except curses.error:
                    pass  # flag emoji can overflow narrow terminals; ignore
            label = f"{state['percent']}% complete"
            if percent_row < h2:
                self.stdscr.move(percent_row, 0)
                self.stdscr.clrtoeol()
                self.stdscr.addstr(percent_row, max(0, (w2 - len(label)) // 2), label, curses.A_DIM)

        def set_progress(percent):
            state["percent"] = max(0, min(100, percent))
            _draw_mountain()
            self.stdscr.refresh()

        def log(line):
            log_buf.append(line)
            h2, w2 = self.stdscr.getmaxyx()
            visible = log_buf[-(h2 - log_top - 1):] if h2 > log_top + 1 else []
            for i in range(log_top, h2 - 1):
                self.stdscr.move(i, 0)
                self.stdscr.clrtoeol()
            for i, l in enumerate(visible):
                self.stdscr.addstr(log_top + i, 2, l[:w2 - 4])
            self.stdscr.refresh()

        _draw_mountain()
        self.stdscr.refresh()
        return log, set_progress

    def error(self, title, message):
        self.info(f"ERROR: {title}", [message], wait=True)
