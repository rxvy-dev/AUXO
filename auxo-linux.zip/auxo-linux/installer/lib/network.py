"""
auxo-install / network.py
Connectivity check and Wi-Fi scan/connect, built on nmcli since
NetworkManager is already running in the live environment. No extra
packages needed beyond networkmanager (already in packages.x86_64).
"""
import subprocess


def is_connected(timeout=3):
    """Quick real-world connectivity check (not just 'has an IP')."""
    try:
        r = subprocess.run(
            ["ping", "-c", "1", "-W", str(timeout), "1.1.1.1"],
            capture_output=True, timeout=timeout + 2,
        )
        return r.returncode == 0
    except Exception:
        return False


def ethernet_connected():
    try:
        out = subprocess.run(["nmcli", "-t", "-f", "TYPE,STATE", "device"],
                              capture_output=True, text=True, timeout=5)
    except Exception:
        return False
    for line in out.stdout.splitlines():
        parts = line.split(":")
        if len(parts) >= 2 and parts[0] == "ethernet" and parts[1] == "connected":
            return True
    return False


def list_wifi(rescan=True):
    """Returns a de-duplicated, signal-sorted list of {ssid, signal, secured}."""
    if rescan:
        subprocess.run(["nmcli", "device", "wifi", "rescan"],
                        capture_output=True, timeout=15)
    try:
        out = subprocess.run(
            ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"],
            capture_output=True, text=True, timeout=15,
        )
    except Exception:
        return []
    networks = []
    seen = set()
    for line in out.stdout.splitlines():
        parts = line.split(":")
        if len(parts) < 3:
            continue
        ssid, signal, security = parts[0], parts[1], parts[2]
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        networks.append({
            "ssid": ssid,
            "signal": signal or "0",
            "secured": bool(security.strip()),
        })
    networks.sort(key=lambda n: -int(n["signal"] or 0))
    return networks


def connect_wifi(ssid, password=None, timeout=30):
    cmd = ["nmcli", "device", "wifi", "connect", ssid]
    if password:
        cmd += ["password", password]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception as e:
        return False, str(e)
    return r.returncode == 0, (r.stdout + r.stderr).strip()
