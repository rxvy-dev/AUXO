#!/usr/bin/env bash
# Build the bootable Auxo Linux ISO.
#
# Requirements (run this on Arch Linux or inside an Arch container/VM):
#   sudo pacman -S --needed archiso git
#
# Usage:
#   ./build-iso.sh          # build ISO to ./out/
set -e -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${ROOT}/work"
OUT="${ROOT}/out"
STAGE="${ROOT}/archiso/airootfs/root/auxo-linux"

echo "==> Staging installer + post-install tooling into airootfs..."
rm -rf "${STAGE}"
mkdir -p "${STAGE}"
cp -r "${ROOT}/installer" "${STAGE}/installer"
cp -r "${ROOT}/post-install" "${STAGE}/post-install"
chmod +x "${STAGE}/installer/auxo-install" "${STAGE}/post-install/auxo-tweak"

echo "==> Redirecting pacman package cache onto the bind-mounted volume..."
mkdir -p "${ROOT}/pkgcache"
if [ ! -L /var/cache/pacman/pkg ]; then
    rm -rf /var/cache/pacman/pkg
    ln -s "${ROOT}/pkgcache" /var/cache/pacman/pkg
fi

echo "==> Running mkarchiso (requires root)..."
mkdir -p "${OUT}"
if [ "$(id -u)" -eq 0 ]; then
    mkarchiso -v -w "${WORK}" -o "${OUT}" "${ROOT}/archiso"
else
    sudo mkarchiso -v -w "${WORK}" -o "${OUT}" "${ROOT}/archiso"
fi

echo "==> Done. ISO is in ${OUT}/"
