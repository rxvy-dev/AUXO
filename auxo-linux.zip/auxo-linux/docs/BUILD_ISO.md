# Building the Auxo Linux ISO

## Requirements
- A machine (or VM/container) running **Arch Linux**, since `mkarchiso` is
  an Arch-only tool.
- Packages: `archiso`, `git`.
- ~5GB free disk space and an internet connection (packages are fetched
  live from Arch mirrors during the build).

## Steps

```bash
sudo pacman -Syu --needed archiso git
git clone <this-repo-url> auxo-linux
cd auxo-linux
./build-iso.sh
```

This will:
1. Copy `installer/` and `post-install/` into
   `archiso/airootfs/root/auxo-linux/` (so they ship inside the live ISO).
2. Run `mkarchiso -v -w work -o out archiso/`.
3. Produce `out/auxo-linux-<version>-x86_64.iso`.

Build takes 10–30 minutes depending on connection speed and CPU (squashfs
compression is the slow part — `zstd -19` in `profiledef.sh` favors smaller
ISOs over build speed; drop to `-Xcompression-level 9` for faster iteration).

## Testing without real hardware

```bash
qemu-system-x86_64 -m 4G -enable-kvm -boot d -cdrom out/auxo-linux-*.iso \
  -drive file=test-disk.qcow2,format=qcow2
```
Create `test-disk.qcow2` first with `qemu-img create -f qcow2 test-disk.qcow2 40G`.
For dual-boot testing, attach a second qcow2 with an existing OS already
installed on it (or a Windows installer ISO) as a second `-cdrom`/`-drive`.

## Customizing what ships on the ISO

- **Live-environment packages** (tools available *before* install, e.g.
  `parted`, `cryptsetup`): edit `archiso/packages.x86_64`.
- **Installable component catalog** (what `auxo-install` and `auxo-tweak`
  offer): edit `installer/config/profiles.json` — this affects the
  *installed* system, not the live ISO itself.
- **Branding**: `archiso/profiledef.sh` (ISO label/name) and
  `archiso/airootfs/etc/motd` (login banner).
- **Boot behavior**: `archiso/airootfs/root/customize_airootfs.sh` controls
  whether `auxo-install` auto-launches on tty1 (set `AUXO_SKIP_AUTOSTART=1`
  as a kernel boot parameter to disable this per-boot).

## Signing / official releases

For real distribution you'll want to GPG-sign the ISO and publish checksums.
`mkarchiso` supports this via `-g`/`-G` flags — see `man mkarchiso` for the
current options, since these are Arch-tooling flags outside this project's
control and can change with archiso versions.
