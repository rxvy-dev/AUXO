# Auxo Linux

An Arch-based distribution built around one idea: **every major component is
swappable, at install time or afterward, and installing alongside your
existing OS is a first-class, safe path** — not an afterthought.

## What's actually in this repo

| Path | What it is |
|---|---|
| `installer/auxo-install` | The TUI installer. Pure Python stdlib (`curses`), no pip deps — runs on any bare Arch live ISO. |
| `installer/lib/` | Disk detection, curses widgets, install steps, session state. |
| `installer/config/profiles.json` | The full catalog of swappable components (kernels, init systems, DEs, WMs, AUR helpers, shells, bootloaders, network managers). Add a JSON entry, get a new option in the wizard — no code changes needed. |
| `post-install/auxo-tweak` | Run this anytime after install to swap DE/WM/kernel/shell/AUR helper/bootloader/accent color, or rescan for other OSes. |
| `post-install/auxo-fetch` | A neofetch-style system banner: the Auxo mountain logo (in your chosen accent color) next to kernel/uptime/package/DE info. |
| `post-install/auxo-choose` | Live-preview accent color picker — cycle colors with arrow keys, see the mountain logo recolor in real time, confirm to save. |
| `installer/lib/ascii_art.py`, `installer/lib/theme.py` | The shared logo + color-palette system used by the installer, `auxo-fetch`, and `auxo-choose`. |
| `installer/lib/network.py` | Connectivity check + Wi-Fi scan/connect (via `nmcli`). The wizard checks for internet right after the color picker and offers a Wi-Fi network list if you're offline. |
| `archiso/` | The Arch `archiso` profile that turns all of the above into a real bootable ISO. |
| `build-iso.sh` | Stages everything and calls `mkarchiso` for you. |

## Branding & theming

The installer opens with a full mountain-logo splash screen, then asks you
to pick an accent color with a **live-preview picker** — cycle the palette
with arrow keys and watch the logo recolor in real time. That choice is
baked into your fresh install (colorized `/etc/motd`,
`~/.config/auxo/theme.conf`), and you can change it anytime after with
`auxo-choose`. `auxo-fetch` reads the same theme file, so your accent color
is consistent everywhere.

## Window manager dotfiles

Any `window_managers` entry in `profiles.json` can carry a `"dotfiles"`
repo URL. If set, the installer (and `auxo-tweak`) automatically clones it
for the new user and applies it (runs `install.sh` if present, otherwise
copies a `.config/` or `config/` directory into `~/.config`). Out of the
box, choosing **Hyprland** auto-clones
[rxvy-dev/rxvy-hyprland-dotfiles](https://github.com/rxvy-dev/rxvy-hyprland-dotfiles)
— no manual setup needed. Add the same key to any other WM entry to give it
its own default dotfiles.

## Why this is "more freedom than any distro"

Most distros pick *one* DE, *one* init system, *one* AUR helper and bake it
in. Auxo doesn't pick for you:

- **Kernel**: stable, LTS, Zen, or Hardened — and `auxo-tweak` lets you install
  more than one side-by-side; your bootloader menu offers all of them.
- **Init system**: systemd (default), runit, OpenRC, or s6 — a choice almost
  no beginner-friendly Arch-based distro exposes.
- **Desktop**: Plasma, GNOME, Xfce, MATE, Cinnamon, LXQt, or go DE-less and
  pick a window manager instead (Hyprland, Sway, i3, bspwm, dwm, Openbox).
- **AUR helper, shell, bootloader, network stack**: all pluggable.
- **Nothing is permanent.** `auxo-tweak` is the same catalog (`profiles.json`)
  exposed as a live, post-install TUI — switch your DE or shell on Tuesday
  and your bootloader on Friday.

## Why the alongside-install is safe

`auxo-install`'s "Install alongside" mode:
1. Reads existing partitions and filesystem types (`lsblk`), and cross-checks
   with `os-prober` — **read-only**, no writes happen during detection.
2. Finds unallocated free space with `parted ... print free` and only ever
   creates a **new** partition inside that free space.
3. Reuses your **existing EFI System Partition** instead of creating a new
   one, so GRUB can chainload every OS on the disk.
4. Installs GRUB with `os-prober` enabled by default, so Windows/other Linux
   installs show up in the boot menu automatically.

It never resizes or reformats an existing partition. If there's no free
space, it tells you to shrink a partition yourself (e.g. Windows Disk
Management) before continuing, rather than trying to do it for you and
risking your existing OS.

## Quickstart

### 1. Build the ISO
```bash
sudo pacman -S --needed archiso git
git clone <this-repo> auxo-linux && cd auxo-linux
./build-iso.sh
# ISO lands in ./out/auxo-linux-*.iso
```
See `docs/BUILD_ISO.md` for details and customization tips.

### 2. Boot it and install
Write the ISO to USB (`dd` or Rufus/Ventoy), boot it, and either wait for the
installer to auto-launch on tty1, or run:
```bash
auxo-install
```

### 3. After install, customize anytime
```bash
auxo-tweak
```

### 4. Unattended / repeatable installs
Every install run saves its full choice-set (minus secrets) to
`/tmp/auxo-install-config.json`. Copy that file and reuse it:
```bash
auxo-install --replay saved-config.json
```

## Extending the component catalog

Everything selectable in the wizard and in `auxo-tweak` comes from
`installer/config/profiles.json`. To add a new window manager, for example:

```json
{"id": "qtile", "name": "Qtile (Python-configured tiling)", "packages": ["qtile", "alacritty"]}
```
No installer code changes needed — it just appears as a new menu option.

## Project status

This is a working installer + archiso profile you can build today. It has
**not** been hardware-tested across every possible partition layout — treat
it like any new distro installer: try it in a VM first, and always keep a
backup before installing alongside an OS you care about.
