#!/usr/bin/env bash
# Auxo Linux archiso profile definition
# Build with: sudo mkarchiso -v -w /tmp/auxo-work -o /tmp/auxo-out .

iso_name="auxo-linux"
iso_label="AUXOLINUX"
iso_publisher="Auxo Linux <https://example.org>"
iso_application="Auxo Linux Live/Installer"
iso_version="$(date +%Y.%m.%d-%H%M)"
install_dir="auxo"
buildmodes=('iso')
# Modern unified boot mode only (UEFI). BIOS/legacy syslinux support is
# deliberately dropped here to keep the profile simple and low-risk to
# build; add 'bios.syslinux' back plus a syslinux/ directory if you need
# to boot on old BIOS-only hardware.
bootmodes=('uefi.systemd-boot')
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'zstd' '-Xcompression-level' '19')
file_permissions=(
  ["/root"]="0:0:750"
  ["/root/auxo-linux/installer/auxo-install"]="0:0:755"
  ["/root/auxo-linux/post-install/auxo-tweak"]="0:0:755"
  ["/etc/motd"]="0:0:644"
)
