#!/usr/bin/env bash
# Runs inside the live filesystem during ISO build (as root, chrooted).
set -e -u

systemctl enable NetworkManager
systemctl enable sshd
systemctl enable haveged
systemctl mask systemd-firstboot.service
passwd -d root

# Required for pacstrap to work at all: without an initialized keyring,
# package signature verification fails with "keyring is not writable"
# and the whole install aborts.
pacman-key --init
pacman-key --populate archlinux

# Rebrand from generic Arch to Auxo. Done here (post-pacstrap) rather than
# as pre-placed airootfs files, since the 'filesystem' package owns these
# paths and placing conflicting files before pacstrap can cause pacman to
# refuse the install with a file-conflict error.
cat > /etc/os-release <<'EOF'
NAME="Auxo Linux"
PRETTY_NAME="Auxo Linux"
ID=auxo
ID_LIKE=arch
BUILD_ID=rolling
ANSI_COLOR="38;2;0;175;175"
LOGO=auxo-logo
EOF

cat > /etc/issue <<'EOF'
Auxo Linux \r (\l)

EOF

# Make the installer + tools reachable as plain commands from any live shell
ln -sf /root/auxo-linux/installer/auxo-install /usr/local/bin/auxo-install
ln -sf /root/auxo-linux/post-install/auxo-tweak /usr/local/bin/auxo-tweak
ln -sf /root/auxo-linux/post-install/auxo-fetch /usr/local/bin/auxo-fetch
ln -sf /root/auxo-linux/post-install/auxo-choose /usr/local/bin/auxo-choose
ln -sf /root/auxo-linux/post-install/auxo-timecapsule /usr/local/bin/auxo-timecapsule
chmod +x /root/auxo-linux/installer/auxo-install
chmod +x /root/auxo-linux/post-install/auxo-tweak
chmod +x /root/auxo-linux/post-install/auxo-fetch
chmod +x /root/auxo-linux/post-install/auxo-choose
chmod +x /root/auxo-linux/post-install/auxo-timecapsule

# Launch the installer automatically when root logs into tty1, but let the
# user Ctrl+C out to a normal shell if they just want to poke around first.
cat >> /root/.bash_profile <<'EOF'

if [ -z "$AUXO_SKIP_AUTOSTART" ] && [ "$(tty)" = "/dev/tty1" ]; then
    echo "Starting auxo-install in 3 seconds... (Ctrl+C to cancel and get a shell)"
    sleep 3
    # Best-effort mirror refresh for faster/more reliable pacstrap. Skips
    # silently if there's no network yet or it takes too long — the
    # baked-in mirrorlist already works on its own as a fallback.
    timeout 15 reflector --latest 10 --sort rate --protocol https \
        --save /etc/pacman.d/mirrorlist >/dev/null 2>&1 || true
    auxo-install || true
fi
EOF
